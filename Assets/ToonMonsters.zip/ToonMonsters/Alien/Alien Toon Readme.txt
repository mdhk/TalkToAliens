FEATURES

• 1223 tris (ship 550tris, alien 673tris)
• 7 Animations
• Shuriken Particle System Smoke
• Sample Scene

Unluck Software
http://www.chemicalbliss.com/

Thanks for purchasing this asset
Have fun with Unity!